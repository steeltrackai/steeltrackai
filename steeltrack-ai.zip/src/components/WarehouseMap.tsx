import React, { useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Text as ThreeText, Box } from '@react-three/drei';
import { Stage, Layer, Rect, Text as KonvaText, Group } from 'react-konva';

interface Level {
  id: string;
  levelName: string;
  productName?: string;
  status?: 'Standard' | 'NearExpiry' | 'Empty';
}

interface Block {
  id: string;
  x: number;
  y: number;
  name: string;
  levels: Level[];
}

const blocks: Block[] = [
  { 
    id: '1', x: 100, y: 100, name: 'AISLE 01', 
    levels: [
      { id: 'l1', levelName: 'Nível 1', productName: 'Soybean Oil', status: 'Standard' },
      { id: 'l2', levelName: 'Nível 2', productName: 'Rice', status: 'NearExpiry' }
    ]
  },
  { 
    id: '2', x: 300, y: 100, name: 'AISLE 02', 
    levels: [
      { id: 'l3', levelName: 'Nível 1', productName: 'Water', status: 'Standard' }
    ]
  },
];

const WarehouseMap2D = () => (
  <Stage width={800} height={600} className="bg-zinc-900">
    <Layer>
      {blocks.map((block) => (
        <Group key={block.id} x={block.x} y={block.y}>
          <Rect width={100} height={40} fill="#71717a" cornerRadius={4} />
          {block.levels.map((level, index) => (
            <Rect 
              key={level.id}
              x={10} y={-index * 20 - 20} width={80} height={15}
              fill={level.status === 'NearExpiry' ? '#ef4444' : (level.status === 'Standard' ? '#3b82f6' : 'white')}
              stroke={level.status === 'Empty' ? '#a1a1aa' : 'transparent'}
              cornerRadius={2}
            />
          ))}
          <KonvaText text={block.name} fill="white" fontSize={14} fontStyle="bold" y={-60} />
        </Group>
      ))}
    </Layer>
  </Stage>
);

const WarehouseMap3D = () => (
  <Canvas camera={{ position: [0, 8, 12], fov: 50 }}>
    <ambientLight intensity={0.6} />
    <pointLight position={[10, 10, 10]} />
    
    {/* Floor Layout */}
    {/* Rack Area 1 */}
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[-2.5, -0.49, 0]}>
      <planeGeometry args={[3, 20]} />
      <meshStandardMaterial color="#3f3f46" />
    </mesh>
    {/* Corridor */}
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.49, 0]}>
      <planeGeometry args={[1, 20]} />
      <meshStandardMaterial color="#27272a" />
    </mesh>
    {/* Rack Area 2 */}
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[2.5, -0.49, 0]}>
      <planeGeometry args={[3, 20]} />
      <meshStandardMaterial color="#3f3f46" />
    </mesh>

    {blocks.map((block, i) => (
      <group key={block.id} position={[(i % 2 === 0 ? -2.5 : 2.5), 0, (block.y - 100) / 50]} rotation={[0, (i % 2 === 0 ? Math.PI / 2 : -Math.PI / 2), 0]}>
        {/* Rack Structure (4 posts) */}
        <Box args={[0.1, 2, 0.1]} position={[-0.7, 0.5, -0.2]}><meshStandardMaterial color="#52525b" /></Box>
        <Box args={[0.1, 2, 0.1]} position={[0.7, 0.5, -0.2]}><meshStandardMaterial color="#52525b" /></Box>
        <Box args={[0.1, 2, 0.1]} position={[-0.7, 0.5, 0.2]}><meshStandardMaterial color="#52525b" /></Box>
        <Box args={[0.1, 2, 0.1]} position={[0.7, 0.5, 0.2]}><meshStandardMaterial color="#52525b" /></Box>
        
        {/* Pallets (Status Indicators) */}
        {block.levels.map((level, index) => (
          <group key={level.id} position={[0, index * 0.6 + 0.2, 0]}>
            <Box args={[1.2, 0.3, 0.4]}>
              <meshStandardMaterial 
                color={level.status === 'NearExpiry' ? '#ef4444' : (level.status === 'Standard' ? '#3b82f6' : '#ffffff')} 
                wireframe={level.status === 'Empty'}
              />
            </Box>
            <ThreeText position={[0, 0, 0.21]} fontSize={0.15} color="black">
              {level.productName || ''}
            </ThreeText>
          </group>
        ))}
        <ThreeText position={[0, 2.5, 0]} fontSize={0.5} color="white">{block.name}</ThreeText>
      </group>
    ))}
    <OrbitControls />
  </Canvas>
);

interface WarehouseMapProps {
  width?: number;
  height?: number;
}

export default function WarehouseMap({ width, height }: WarehouseMapProps) {
  const [viewMode, setViewMode] = useState<'2D' | '3D'>('3D');

  return (
    <div className="h-full w-full bg-zinc-900 relative" style={{ width, height }}>
      <div className="absolute top-4 right-4 z-50 flex gap-2">
        <button 
          onClick={() => setViewMode('2D')} 
          className={`p-2 rounded ${viewMode === '2D' ? 'bg-blue-600' : 'bg-zinc-700'} text-white`}
        >
          2D
        </button>
        <button 
          onClick={() => setViewMode('3D')} 
          className={`p-2 rounded ${viewMode === '3D' ? 'bg-blue-600' : 'bg-zinc-700'} text-white`}
        >
          3D
        </button>
      </div>
      
      <div className={`h-full w-full ${viewMode === '2D' ? 'block' : 'hidden'}`}>
        <WarehouseMap2D />
      </div>
      
      <div className={`h-full w-full ${viewMode === '3D' ? 'block' : 'hidden'}`}>
        <WarehouseMap3D />
      </div>
    </div>
  );
}
